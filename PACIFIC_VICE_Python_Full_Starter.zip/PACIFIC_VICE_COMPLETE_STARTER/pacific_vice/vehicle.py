from .geometry import make_cube


class Vehicle:
    def __init__(self, render, position=(7, 1, 0.7)):
        self.node = make_cube(render, "StarterCar", position, (1.7, 3.0, 0.65), (0.72, 0.12, 0.10, 1))
        self.speed = 0.0
        self.max_speed = 18.0

    def update(self, dt):
        forward = 0
        if __import__("direct.showbase.ShowBaseGlobal", fromlist=["base"]).base.mouseWatcherNode.is_button_down("w"):
            forward += 1
        if __import__("direct.showbase.ShowBaseGlobal", fromlist=["base"]).base.mouseWatcherNode.is_button_down("s"):
            forward -= 1
        if __import__("direct.showbase.ShowBaseGlobal", fromlist=["base"]).base.mouseWatcherNode.is_button_down("a"):
            self.node.setH(self.node.getH() + 75 * dt)
        if __import__("direct.showbase.ShowBaseGlobal", fromlist=["base"]).base.mouseWatcherNode.is_button_down("d"):
            self.node.setH(self.node.getH() - 75 * dt)
        self.speed += forward * 10 * dt
        self.speed *= 0.985
        self.speed = max(-7, min(self.max_speed, self.speed))
        self.node.setY(self.node, self.speed * dt)
