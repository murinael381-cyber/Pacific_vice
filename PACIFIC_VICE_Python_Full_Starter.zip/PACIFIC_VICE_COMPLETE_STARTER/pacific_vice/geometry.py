from panda3d.core import Geom, GeomNode, GeomTriangles, GeomVertexData, GeomVertexFormat, GeomVertexWriter
from panda3d.core import NodePath, Vec3


def make_cube(parent, name, position, scale, color):
    """Create a simple colored cube without external model files."""
    fmt = GeomVertexFormat.getV3n3c4()
    vdata = GeomVertexData(name, fmt, Geom.UHStatic)
    vertex = GeomVertexWriter(vdata, "vertex")
    normal = GeomVertexWriter(vdata, "normal")
    col = GeomVertexWriter(vdata, "color")

    # Six faces, four vertices per face; normals keep lighting readable.
    faces = [
        ((0, 0, -1), [(-1,-1,-1),(1,-1,-1),(1,1,-1),(-1,1,-1)]),
        ((0, 0, 1), [(-1,-1,1),(-1,1,1),(1,1,1),(1,-1,1)]),
        ((0, -1, 0), [(-1,-1,-1),(-1,-1,1),(1,-1,1),(1,-1,-1)]),
        ((0, 1, 0), [(-1,1,-1),(1,1,-1),(1,1,1),(-1,1,1)]),
        ((-1, 0, 0), [(-1,-1,-1),(-1,1,-1),(-1,1,1),(-1,-1,1)]),
        ((1, 0, 0), [(1,-1,-1),(1,-1,1),(1,1,1),(1,1,-1)]),
    ]
    tris = GeomTriangles(Geom.UHStatic)
    idx = 0
    for n, points in faces:
        for p in points:
            vertex.addData3(*p)
            normal.addData3(*n)
            col.addData4(*color)
        tris.addVertices(idx, idx+1, idx+2)
        tris.addVertices(idx, idx+2, idx+3)
        idx += 4
    geom = Geom(vdata)
    geom.addPrimitive(tris)
    node = GeomNode(name)
    node.addGeom(geom)
    path = parent.attachNewNode(node)
    path.setName(name)
    path.setPos(*position)
    path.setScale(*scale)
    return path
