from direct.showbase.DirectObject import DirectObject
from panda3d.core import Vec3
from .geometry import make_cube


class Player(DirectObject):
    def __init__(self, game):
        self.game = game
        self.node = make_cube(game.render, "Player", (0, 0, 1), (0.45, 0.35, 1.0), (0.88, 0.76, 0.62, 1))
        self.keys = {k: False for k in ("w", "a", "s", "d", "shift")}
        for key in ("w", "a", "s", "d", "shift"):
            self.accept(key, self.set_key, [key, True])
            self.accept(key + "-up", self.set_key, [key, False])
        self.accept("space", self.jump)
        self.vertical_speed = 0.0

    def set_key(self, key, value):
        self.keys[key] = value

    def jump(self):
        if self.node.getZ() <= 1.01:
            self.vertical_speed = 7.0

    def update(self, dt):
        move = Vec3(0, 0, 0)
        if self.keys["w"]: move.y += 1
        if self.keys["s"]: move.y -= 1
        if self.keys["a"]: move.x -= 1
        if self.keys["d"]: move.x += 1
        if move.lengthSquared() > 0:
            move.normalize()
            speed = 14 if self.keys["shift"] else 7
            self.node.setX(self.node.getX() + move.x * speed * dt)
            self.node.setY(self.node.getY() + move.y * speed * dt)
            self.node.setH(self.node.getH() + move.x * -100 * dt)

        self.vertical_speed -= 18 * dt
        z = self.node.getZ() + self.vertical_speed * dt
        if z < 1:
            z = 1
            self.vertical_speed = 0
        self.node.setZ(z)
