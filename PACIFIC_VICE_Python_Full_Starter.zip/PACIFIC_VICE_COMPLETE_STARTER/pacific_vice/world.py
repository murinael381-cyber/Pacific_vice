from .geometry import make_cube


def build_world(render):
    # Broad island base and coastal strip.
    make_cube(render, "Island", (0, 0, -0.45), (110, 110, 0.45), (0.20, 0.43, 0.22, 1))
    make_cube(render, "Boulevard", (0, -12, 0.02), (108, 6, 0.08), (0.12, 0.13, 0.15, 1))
    make_cube(render, "Beach", (0, -36, -0.02), (108, 15, 0.10), (0.84, 0.73, 0.51, 1))
    make_cube(render, "Ocean", (0, -66, -0.2), (108, 16, 0.12), (0.03, 0.30, 0.54, 1))

    building_colors = [
        (0.63, 0.67, 0.73, 1), (0.72, 0.66, 0.56, 1),
        (0.48, 0.55, 0.64, 1), (0.76, 0.76, 0.73, 1)
    ]
    for row in range(4):
        for col in range(8):
            x = -52 + col * 15
            y = 9 + row * 17
            h = 7 + ((row * 3 + col) % 6) * 2.8
            make_cube(render, f"Building_{row}_{col}", (x, y, h/2),
                      (4.8, 5.0, h/2), building_colors[(row+col) % len(building_colors)])

    # Palm-tree placeholders: trunk and a simple crossed canopy.
    for i, x in enumerate(range(-90, 100, 18)):
        make_cube(render, f"PalmTrunk_{i}", (x, -27, 2.3), (0.20, 0.20, 2.3), (0.38, 0.23, 0.12, 1))
        make_cube(render, f"PalmLeavesA_{i}", (x, -27, 4.7), (1.8, 0.28, 0.16), (0.10, 0.36, 0.15, 1))
        leaf_b = make_cube(render, f"PalmLeavesB_{i}", (x, -27, 4.7), (0.28, 1.8, 0.16), (0.12, 0.40, 0.16, 1))
        leaf_b.setH(35)
