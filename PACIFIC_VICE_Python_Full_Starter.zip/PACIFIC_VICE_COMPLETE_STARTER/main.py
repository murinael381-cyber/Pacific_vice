from direct.showbase.ShowBase import ShowBase
from direct.task import Task
from direct.gui.OnscreenText import OnscreenText
from panda3d.core import AmbientLight, DirectionalLight, Vec4, Vec3, TextNode
from pacific_vice.world import build_world
from pacific_vice.player import Player
from pacific_vice.vehicle import Vehicle


class PacificViceGame(ShowBase):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("PACIFIC VICE")
        self.setBackgroundColor(0.48, 0.72, 0.90, 1)
        self.disableMouse()

        self.setup_lighting()
        build_world(self.render)

        self.player = Player(self)
        self.vehicle = Vehicle(self.render, position=(7, 1, 0.7))
        self.in_vehicle = False

        self.camera_distance = 12
        self.camera_height = 5
        self.accept("escape", self.userExit)
        self.accept("e", self.toggle_vehicle)
        self.hud = OnscreenText(
            text="PACIFIC VICE  |  WASD: движение  SHIFT: бег  SPACE: прыжок  E: сесть/выйти из машины",
            pos=(-1.29, 0.93), scale=0.038, fg=(1, 1, 1, 1),
            align=TextNode.ALeft, mayChange=True
        )
        self.taskMgr.add(self.update, "game_update")

    def setup_lighting(self):
        ambient = AmbientLight("ambient")
        ambient.setColor(Vec4(0.62, 0.64, 0.72, 1))
        self.render.setLight(self.render.attachNewNode(ambient))
        sun = DirectionalLight("sun")
        sun.setColor(Vec4(1.0, 0.93, 0.82, 1))
        sun_np = self.render.attachNewNode(sun)
        sun_np.setHpr(-35, -55, 0)
        self.render.setLight(sun_np)

    def toggle_vehicle(self):
        if not self.in_vehicle:
            if (self.player.node.getPos() - self.vehicle.node.getPos()).length() < 5:
                self.in_vehicle = True
                self.player.node.hide()
                self.hud.setText("PACIFIC VICE  |  В машине: W/S газ и задний ход  A/D поворот  E выйти")
        else:
            self.in_vehicle = False
            self.player.node.show()
            self.player.node.setPos(self.vehicle.node.getPos() + Vec3(2, 0, 0))
            self.hud.setText("PACIFIC VICE  |  WASD: движение  SHIFT: бег  SPACE: прыжок  E: сесть/выйти из машины")

    def update(self, task):
        dt = min(globalClock.getDt(), 0.05)
        if self.in_vehicle:
            self.vehicle.update(dt)
            target = self.vehicle.node.getPos()
            target.z += 2
        else:
            self.player.update(dt)
            target = self.player.node.getPos()
            target.z += 1.2

        desired = target + Vec3(0, -self.camera_distance, self.camera_height)
        self.camera.setPos(self.camera.getPos() + (desired - self.camera.getPos()) * min(1, dt * 4))
        self.camera.lookAt(target)
        return Task.cont


if __name__ == "__main__":
    PacificViceGame().run()
